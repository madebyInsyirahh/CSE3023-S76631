<%-- 
    Document   : CarForm
    Created on : 2 Jun 2026, 3:55:07 pm
    Author     : NurInsyirahJaafar
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Vehicle Matrix Configuration</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <style>
            body {
                background-color: #f8fafc;
                font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            }
            .navbar-custom {
                background-color: #1e293b;
            }
            .form-card {
                background: #ffffff;
                border: none;
                border-radius: 16px;
                box-shadow: 0 4px 30px rgba(0, 0, 0, 0.03);
                padding: 40px;
                margin-top: 40px;
                margin-bottom: 40px;
            }
            .form-label-custom {
                font-weight: 600;
                color: #475569;
                font-size: 0.825rem;
                text-transform: uppercase;
                letter-spacing: 0.04em;
                margin-bottom: 8px;
                display: block;
            }
            .form-control {
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                padding: 12px 14px;
                font-size: 0.95rem;
                transition: all 0.2s ease;
                color: #1e293b;
            }
            .form-control:focus {
                border-color: #3b82f6;
                box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.12);
                background-color: #ffffff;
            }
            .input-group-text-custom {
                background-color: #f8fafc;
                border: 1px solid #cbd5e1;
                border-right: none;
                border-top-left-radius: 8px;
                border-bottom-left-radius: 8px;
                color: #64748b;
                font-weight: 600;
                padding-left: 16px;
                padding-right: 16px;
            }
            .price-input {
                border-top-left-radius: 0px !important;
                border-bottom-left-radius: 0px !important;
            }
            .btn-save-custom {
                background-color: #10b981;
                border: none;
                color: white;
                font-weight: 600;
                padding: 14px;
                border-radius: 8px;
                width: 100%;
                margin-top: 10px;
                transition: all 0.2s ease;
                box-shadow: 0 4px 12px rgba(16, 185, 129, 0.15);
            }
            .btn-save-custom:hover {
                background-color: #059669;
                transform: translateY(-1px);
            }
        </style>
    </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-md navbar-dark navbar-custom py-3">
                <div class="container">
                    <a href="../index.jsp" class="navbar-brand fw-bold d-flex align-items-center"><i class="bi bi-car-front-fill me-2 fs-4 text-info"></i>Car Shop Management</a>
                    <div class="navbar-nav ms-auto">
                        <a href="list" class="nav-link"><i class="bi bi-arrow-left me-1"></i> Back to Inventory</a>
                    </div>
                </div>
            </nav>
        </header>

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="form-card">
                        <c:if test="${car != null}">
                            <form action="update" method="post">
                            </c:if>
                            <c:if test="${car == null}">
                                <form action="insert" method="post">
                                </c:if>
                                <div class="text-center mb-4">
                                    <div style="display:inline-flex; background-color: #f0fdf4; color:#10b981; width:52px; height:52px; border-radius:50%; align-items:center; justify-content:center; font-size:1.3rem;" class="mb-3">
                                        <i class="bi ${car != null ? 'bi-pencil-square' : 'bi-plus-lg'}"></i>
                                    </div>
                                    <h3 class="fw-bold text-dark m-0" style="letter-spacing: -0.02em;">
                                        <c:choose>
                                            <c:when test="${car != null}">Modify Asset Profile</c:when>
                                            <c:otherwise>Register Showroom Car</c:otherwise>
                                        </c:choose>
                                    </h3>
                                    <p class="text-muted small mt-1">Configure asset specifications and schema fields pricing values</p>
                                </div>

                                <c:if test="${car != null}">
                                    <input type="hidden" name="id" value="<c:out value='${car.carId}' />" />
                                </c:if>

                                <div class="mb-3">
                                    <label class="form-label-custom"><i class="bi bi-bookmark-star me-2 text-muted"></i>Car Brand / Manufacture</label>
                                    <input type="text" value="<c:out value='${car.brand}' />" class="form-control" name="brand" placeholder="e.g., Proton, Honda, Toyota" required="required">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label-custom"><i class="bi bi-info-circle me-2 text-muted"></i>Model Specification Line</label>
                                    <input type="text" value="<c:out value='${car.model}' />" class="form-control" name="model" placeholder="e.g., S70 1.5T Executive, Civic RS" required="required">
                                </div>

                                <div class="row">
                                    <div class="mb-4 col-md-5">
                                        <label class="form-label-custom"><i class="bi bi-gear-wide-connected me-2 text-muted"></i>Engine Cylinders</label>
                                        <input type="number" value="<c:out value='${car.cylinder}' />" class="form-control" name="cylinder" placeholder="e.g., 3, 4" required="required">
                                    </div>
                                    <div class="mb-4 col-md-7">
                                        <label class="form-label-custom"><i class="bi bi-tag-fill me-2 text-muted"></i>Retail Market Valuation</label>
                                        <div class="input-group">
                                            <span class="input-group-text input-group-text-custom">RM</span>
                                            <input type="number" step="0.01" value="<c:out value='${car.price}' />" class="form-control price-input" name="price" placeholder="0.00" required="required">
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-save-custom shadow-sm text-white">
                                    <i class="bi bi-cloud-arrow-up-fill me-2"></i>Save Showroom Record Entry
                                </button>
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>