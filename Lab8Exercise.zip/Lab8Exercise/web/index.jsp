<%-- 
    Document   : index
    Created on : 2 Jun 2026, 3:57:50 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Car Shop Management Hub</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <style>
            body {
                background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            }
            .welcome-card {
                background: #ffffff;
                border: none;
                border-radius: 16px;
                box-shadow: 0 10px 30px rgba(30, 41, 59, 0.08);
                padding: 50px 40px;
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }
            .welcome-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 15px 35px rgba(30, 41, 59, 0.12);
            }
            .brand-badge {
                background-color: #f0fdf4;
                color: #10b981;
                padding: 8px 20px;
                border-radius: 50px;
                font-weight: 600;
                font-size: 0.85rem;
                display: inline-block;
                text-transform: uppercase;
                letter-spacing: 0.05em;
            }
            .btn-custom-dark {
                background-color: #1e293b;
                border: none;
                color: #ffffff;
                padding: 14px 30px;
                font-weight: 500;
                border-radius: 8px;
                transition: all 0.2s ease;
            }
            .btn-custom-dark:hover {
                background-color: #0f172a;
                color: #ffffff;
                box-shadow: 0 4px 12px rgba(15, 23, 42, 0.15);
            }
            .btn-custom-success {
                background-color: #10b981;
                border: none;
                color: #ffffff;
                padding: 14px 30px;
                font-weight: 500;
                border-radius: 8px;
                transition: all 0.2s ease;
            }
            .btn-custom-success:hover {
                background-color: #059669;
                color: #ffffff;
                box-shadow: 0 4px 12px rgba(16, 185, 129, 0.15);
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7 text-center">
                    <div class="welcome-card">
                        <span class="brand-badge mb-4"><i class="bi bi-shield-check me-2"></i>Showroom Console</span>
                        <h1 class="fw-bold text-dark mb-2" style="color: #1e293b !important; letter-spacing: -0.03em;">Car Shop Management</h1>
                        <p class="text-muted lead mb-4">Enterprise MVC Inventory Control Hub</p>
                        <hr class="my-4" style="border-top: 2px solid #f1f5f9;">
                        <p class="text-secondary mb-4 mx-md-4">Select an operational dashboard interface link below to view, audit, or configure structural pricing items inside your live showroom asset ledger.</p>
                        <div class="d-grid gap-3 d-sm-flex justify-content-sm-center mt-4">
                            <a class="btn btn-custom-dark btn-lg px-4" href="Lab8Exercise/list" role="button">
                                <i class="bi bi-list-task me-2"></i>Showroom Registry
                            </a>
                            <a class="btn btn-custom-success btn-lg px-4" href="Lab8Exercise/new" role="button">
                                <i class="bi bi-plus-circle me-2"></i>Add New Vehicle
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>