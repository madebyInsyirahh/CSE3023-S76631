<%-- 
    Document   : CarList
    Created on : 2 Jun 2026, 4:02:15 pm
    Author     : NurInsyirahJaafar
--%>

<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Car Shop Showroom</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <style>
            body {
                background-color: #f8fafc;
                font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            }
            .navbar-custom {
                background-color: #1e293b;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            }
            .main-card {
                background: #ffffff;
                border: none;
                border-radius: 14px;
                box-shadow: 0 4px 25px rgba(0, 0, 0, 0.02);
                padding: 35px;
                margin-top: 35px;
            }
            .table-custom {
                border-collapse: separate;
                border-spacing: 0 6px;
            }
            .table-custom thead th {
                background-color: #f1f5f9;
                color: #475569;
                text-transform: uppercase;
                font-size: 0.75rem;
                font-weight: 700;
                letter-spacing: 0.05em;
                border: none;
                padding: 16px;
            }
            .table-custom tbody tr {
                background-color: #ffffff;
                transition: all 0.2s ease;
            }
            .table-custom tbody tr:hover {
                background-color: #f8fafc;
                transform: scale(1.002);
            }
            .table-custom tbody td {
                padding: 16px;
                color: #334155;
                border-top: 1px solid #f1f5f9;
                border-bottom: 1px solid #f1f5f9;
            }
            .table-custom tbody tr td:first-child {
                border-left: 1px solid #f1f5f9;
                border-top-left-radius: 8px;
                border-bottom-left-radius: 8px;
                font-weight: 600;
                color: #64748b;
            }
            .table-custom tbody tr td:last-child {
                border-right: 1px solid #f1f5f9;
                border-top-right-radius: 8px;
                border-bottom-right-radius: 8px;
            }
            .price-tag {
                color: #10b981;
                font-weight: 600;
            }
            .cylinder-badge {
                background-color: #eff6ff;
                color: #3b82f6;
                padding: 4px 10px;
                border-radius: 6px;
                font-size: 0.8rem;
                font-weight: 600;
            }
            .btn-edit-custom {
                color: #3b82f6;
                background-color: #eff6ff;
                border: none;
                padding: 6px 12px;
                border-radius: 6px;
                font-size: 0.85rem;
                font-weight: 500;
                transition: all 0.2s;
                text-decoration: none;
            }
            .btn-edit-custom:hover {
                background-color: #3b82f6;
                color: #ffffff;
            }
            .btn-delete-custom {
                color: #ef4444;
                background-color: #fef2f2;
                border: none;
                padding: 6px 12px;
                border-radius: 6px;
                font-size: 0.85rem;
                font-weight: 500;
                transition: all 0.2s;
                text-decoration: none;
            }
            .btn-delete-custom:hover {
                background-color: #ef4444;
                color: #ffffff;
            }
        </style>
    </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-md navbar-dark navbar-custom py-3">
                <div class="container">
                    <a href="../index.jsp" class="navbar-brand fw-bold d-flex align-items-center"><i class="bi bi-car-front-fill me-2 fs-4 text-info"></i>Car Shop Management</a>
                    <div class="navbar-nav ms-auto">
                        <a href="list" class="nav-link active"><i class="bi bi-database-check me-1"></i> Live Inventory</a>
                    </div>
                </div>
            </nav>
        </header>

        <div class="container">
            <div class="main-card">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
                    <div>
                        <h2 class="fw-bold m-0 text-dark" style="letter-spacing: -0.02em;">Showroom Asset Ledger</h2>
                        <small class="text-muted">Live system configurations pulled directly from relational schemas</small>
                    </div>
                    <a href="new" class="btn btn-success px-4 py-2" style="background-color: #10b981; border: none; border-radius: 8px; font-weight: 500; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.15);">
                        <i class="bi bi-plus-lg me-2"></i>Add New Vehicle
                    </a>
                </div>

                <div class="table-responsive">
                    <table class="table table-custom align-middle">
                        <thead>
                            <tr>
                                <th style="width: 12%">ID Map</th>
                                <th style="width: 23%">Brand Make</th>
                                <th style="width: 25%">Model Reference</th>
                                <th style="width: 15%">Cylinders</th>
                                <th style="width: 15%">Market Price</th>
                                <th style="width: 10%" class="text-center">Operations</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach var="car" items="${listCars}">
                                <tr>
                                    <td>#<c:out value="${car.carId}" /></td>
                                    <td class="fw-bold text-dark"><c:out value="${car.brand}" /></td>
                                    <td><c:out value="${car.model}" /></td>
                                    <td><span class="cylinder-badge"><c:out value="${car.cylinder}" /> Valve</span></td>
                                    <td><span class="price-tag">RM <c:out value="${car.price}" /></span></td>
                                    <td class="text-center">
                                        <div class="d-flex justify-content-center gap-2">
                                            <a href="edit?id=<c:out value='${car.carId}' />" class="btn-edit-custom" title="Edit Properties"><i class="bi bi-pencil-square"></i></a>
                                            <a href="delete?id=<c:out value='${car.carId}' />" class="btn-delete-custom" title="Remove Entry" onclick="return confirm('Permanently wipe this asset record configuration from your database?');"><i class="bi bi-trash3-fill"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>
</html>