<%-- 
    Document   : processAuthor
    Created on : 12 May 2026, 3:54:57 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page language="java"%>
<%@page import="java.sql.*"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Lab 6 - Task 2</title>
    </head>
    <body>
        <h1>Lab 6 - Task 2 - Perform creating and retrieving records via JSP page</h1>
        <jsp:useBean id="myAuthor" class="lab6.com.Author" scope="request"/>
        <jsp:setProperty name="myAuthor" property="*"/>
        <%
            int result;

            Class.forName("com.mysql.jdbc.Driver");
            String myURL = "jdbc:mysql://localhost:3307/cse3023";
            Connection myConnection = DriverManager.getConnection(myURL, "root", "");

            String sInsertQry = "INSERT INTO Author(AuthNo, Name, Address, City, State, Zip) VALUES(?, ?, ?, ?, ?, ?)";
            PreparedStatement myPS = myConnection.prepareStatement(sInsertQry);
            myPS.setString(1, myAuthor.getAuthNo());
            myPS.setString(2, myAuthor.getName());
            myPS.setString(3, myAuthor.getAddress());
            myPS.setString(4, myAuthor.getCity());
            myPS.setString(5, myAuthor.getState());
            myPS.setString(6, myAuthor.getZip());

            result = myPS.executeUpdate();
            if (result > 0) {
                out.println("\tRecord sucessfully added into Author table...!");
                out.print("<p>" + "Record with author no " + myAuthor.getAuthNo() + " successfully created...!" + "</p>");
                out.print("<p>" + "Details of record are: " + "</p>");
                out.print("<p>Name: " + myAuthor.getName() + "</p>");
                out.print("<p>Address: " + myAuthor.getAddress() + "</p>");
                out.print("<p>City: " + myAuthor.getCity() + "</p>");
                out.print("<p>State: " + myAuthor.getState() + "</p>");
                out.print("<p>Zip: " + myAuthor.getZip() + "</p>");
            }
            
            // Step 5: Close database connection
            System.out.println("Step 5: Close database connection...!");
            myConnection.close();
            System.out.println("");
            System.out.println("Database connection is closed...!");
        %>
    </body>
</html>
