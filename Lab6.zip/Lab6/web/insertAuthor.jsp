<%-- 
    Document   : insertAuthor
    Created on : 12 May 2026, 3:20:26 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Lab 6 - Task 2</title>
        <style>
            body {
                font-family: "Times New Roman", serif;
                background-color: white;
            }

            .container {
                width: 960px;
                margin: 20px auto;
                border: 1px solid black;
            }
            
            .header {
                padding: 15px;
                border-bottom: 1px solid gray;
            }
            
            .header h1 {
                font-size: 40px;
                margin: 0;
                font-weight: bold;
            }
            
            .content {
                padding: 15px;
                min-height: 280px;
                border-bottom: 1px solid gray;
            }
            
            .title {
                font-size: 18px;
                margin-bottom: 10px;
            }

            table {
                margin-top: 10px;
            }

            td {
                padding: 4px 8px;
                font-size: 16px;
            }

            input[type=text], select {
                width: 170px;
                height: 22px;
                border: 1px solid #bfbfbf;
                font-size: 13px;
                padding-left: 5px;
            }
            
            input[type=submit], input[type=reset] {
                font-size: 12px;
                padding: 2px 8px;
                margin-top: 8px;
            }

            .footer {
                padding: 15px;
                font-size: 14px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Lab 6 - Task 2 - Perform creating and retrieving records via JSP page</h1>
            </div>
            <div class="content">
                <div class="title">Author Registration</div>
                <form action="processAuthor.jsp" method="POST">
                    <table>
                        <tr>
                            <td>Author No</td>
                            <td>
                                <input type="text" name="authNo" placeholder="Eg: UK000XX">
                            </td>
                        </tr>
                        <tr>
                            <td>Name</td>
                            <td>
                                <input type="text" name="name" placeholder="Enter your name">
                            </td>
                        </tr>
                        <tr>
                            <td>Address</td>
                            <td>
                                <input type="text" name="address" placeholder="Enter your address">
                            </td>
                        </tr>
                        <tr>
                            <td>City</td>
                            <td>
                                <input type="text" name="city" placeholder="Enter your city">
                            </td>
                        </tr>
                        <tr>
                            <td>State</td>
                            <td>
                                <input type="text" name="state" placeholder="Enter your state">
                            </td>
                        </tr>
                        <tr>
                            <td>Zip</td>
                            <td>
                                <select name="zip">
                                    <option value="">-- Select Zip --</option>
                                    <option value="43000">43000</option>
                                    <option value="43100">43100</option>
                                    <option value="43200">43200</option>
                                    <option value="43300">43300</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" value="Submit">
                                <input type="reset" value="Cancel">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            <div class="footer">
                &copy;2026 - Nur Insyirah Binti Jaafar
            </div>
        </div>
    </body>
</html>
