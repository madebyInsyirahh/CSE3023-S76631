<%-- 
    Document   : insertStudent
    Created on : 12 May 2026, 4:30:40 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Student Registration</title>
        <style>
            body {
                font-family: "Times New Roman", serif;
                background-color: white;
            }

            .container {
                width: 900px;
                margin: 30px auto;
                border: 1px solid black;
            }

            .content {
                padding: 15px;
                min-height: 250px;
                border-bottom: 1px solid gray;
            }

            .title {
                font-size: 14px;
                margin-bottom: 10px;
            }

            table {
                margin-top: 10px;
            }

            td {
                padding: 4px 8px;
                font-size: 14px;
            }

            input[type=text], select{
                width: 140px;
                height: 20px;
                border: 1px solid #bfbfbf;
                font-size: 12px;
                padding-left: 5px;
            }

            input[type=submit],
            input[type=reset]{
                font-size: 11px;
                padding: 2px 8px;
                margin-top: 5px;
            }

            .footer {
                padding: 10px;
                font-size: 12px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <div class="title">Student Registration</div>
                <form action="processStudent.jsp" method="POST">
                    <table>
                        <tr>
                            <td>Student No</td>
                            <td>
                                <input type="text" name="stuno" placeholder="Eg.: U0000XX" pattern="[A-Z0-9]*" required>
                            </td>
                        </tr>
                        <tr>
                            <td>Name</td>
                            <td>
                                <input type="text" name="name" placeholder="Enter your name" required>
                            </td>
                        </tr>
                        <tr>
                            <td>Program</td>
                            <td>
                                <select name="program">
                                    <option>BSc. Soft. Eng.</option>
                                    <option>BSc. with IM</option>
                                    <option>BSc. in Networking</option>
                                    <option>BSc. in Robotics</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" value="Submit">
                                <input type="reset" value="Cancel">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            <div class="footer">
                &copy;2026 - Nur Insyirah Binti Jaafar
            </div>
        </div>
    </body>
</html>
