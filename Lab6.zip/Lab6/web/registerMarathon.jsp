<%-- 
    Document   : registerMarathon
    Created on : 12 May 2026, 10:25:44 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page language="java"%>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Marathon Registration</title>
        <style>
            body {
                font-family: Arial, sans-serif;
            }

            fieldset {
                width: 500px;
            }

            table {
                width: 100%;
            }

            td {
                padding: 5px;
            }

            input[type=text] {
                width: 150px;
                padding: 3px;
            }

            select {
                width: 70px;
            }

            .button {
                padding: 4px 10px;
            }

            footer {
                margin-top: 20px;
                font-size: 12px;
            }
        </style>
    </head>
    <body>
        <fieldset>
            <legend><b>Registration Form</b></legend>
            <form action="processMarathon.jsp" method="POST">
                <table>
                    <tr>
                        <td>IC No</td>
                        <td>
                            <input type="text" name="icno" placeholder="E.g.: 921110-10-2514" required>
                        </td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td>
                            <input type="text" name="name" placeholder="Enter your name" required>
                        </td>
                    </tr>
                    <tr>
                        <td>Category</td>
                        <td>
                            <select name="category">
                                <option value="5 KM">5 KM</option>
                                <option value="7 KM">7 KM</option>
                                <option value="10 KM">10 KM</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="submit" value="Submit" class="button">
                            <input type="reset" value="Cancel" class="button">
                        </td>
                    </tr>
                </table>
            </form>
        </fieldset>
        <footer>
            &copy;2026 - Nur Insyirah Binti Jaafar
        </footer>
    </body>
</html>
