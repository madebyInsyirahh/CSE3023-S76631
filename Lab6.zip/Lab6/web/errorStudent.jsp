<%-- 
    Document   : errorStudent
    Created on : 12 May 2026, 9:21:39 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page isErrorPage="true"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Lab 6 - Task 3</title>
    </head>
    <body>
        <form id="errorForm" action="insertStudent.jsp" method="POST">
            <h1>Lab 6 - Task 3 - Perform creating and retrieving records via JSP page</h1>
            <p>When inserting record...!</p>
            <p><%= exception.getMessage()%></p>
        </form>
    </body>
</html>
