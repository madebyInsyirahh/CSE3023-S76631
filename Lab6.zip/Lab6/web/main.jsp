<%-- 
    Document   : main
    Created on : 13 May 2026, 12:22:07 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Main Page</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                margin: 0;
                padding: 0;
            }

            .container {
                width: 450px;
                margin: 80px auto;
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0px 0px 10px rgba(0,0,0,0.2);
            }

            h2 {
                text-align: center;
                color: #333;
                margin-bottom: 30px;
            }

            .info {
                margin-bottom: 20px;
            }

            label {
                font-weight: bold;
                color: #555;
                display: inline-block;
                width: 120px;
            }

            span {
                color: #222;
            }
        </style>
    </head>
    <body>
        <%
            String username = (String) session.getAttribute("username");
            String firstname = (String) session.getAttribute("firstname");
            String lastname = (String) session.getAttribute("lastname");

            if (username == null) {
                response.sendRedirect("login.jsp");
            }
        %>
        <div class="container">
            <h2>Welcome to the System</h2>
            <div class="info">
                <label>Username :</label>
                <span><%= username%></span>
            </div>
            <div class="info">
                <label>First Name :</label>
                <span><%= firstname%></span>
            </div>
            <div class="info">
                <label>Last Name :</label>
                <span><%= lastname%></span>
            </div>
        </div>
    </body>
</html>
