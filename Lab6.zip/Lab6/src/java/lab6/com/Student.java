package lab6.com;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Student {
    // Create attributes
    private String stuno;
    private String name;
    private String program;

    // Getter and Setter for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for program
    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    // Getter and Setter for student no
    public String getStuno() {
        Pattern pt = Pattern.compile("[A-Z0-9]*");
        Matcher mt = pt.matcher(stuno);
        boolean bl = mt.matches();
        if (bl == true) {
            return stuno;
        } else {
            return "Invalid Student Number";
        }
    }

    public void setStuno(String stuno) {
        this.stuno = stuno;
    }
}