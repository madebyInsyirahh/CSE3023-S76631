<%-- 
    Document   : processRegistration
    Created on : 14 Apr 2026, 3:59:18 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList" %>
<!DOCTYPE html>
<html>
    <head>
        <title>Registration Details</title>
        <style>
            body {
                font-family: 'Segoe UI', sans-serif;
                margin: 0;
                background-color: #f4f6f9;
            }

            .container {
                width: 60%;
                margin: 40px auto;
                background: white;
                padding: 25px;
                border-radius: 10px;
                box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
            }

            h3 {
                text-align: center;
                color: #2c3e50;
            }

            .info {
                background: #ecf0f1;
                padding: 15px;
                border-radius: 8px;
                margin: 10px 0;
            }

            .info b {
                color: #2c3e50;
            }
        </style>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <div class="container">
            <h3>Registration Details</h3>
            <%
                String name = request.getParameter("studentName");
                String matric = request.getParameter("matricNo");
                String club = request.getParameter("club");

                String member = name + " | " + matric + " | " + club;

                ArrayList<String> directory = (ArrayList<String>) session.getAttribute("clubDirectory");

                if (directory == null) {
                    directory = new ArrayList<String>();
                }

                directory.add(member);
                session.setAttribute("clubDirectory", directory);

                response.sendRedirect("memberDirectory.jsp");
            %>
            <div class="info">
                <p><b>Student Name:</b> <%= name%></p>
            </div>
            <div class="info">
                <p><b>Matric Number:</b> <%= matric%></p>
            </div>
            <div class="info">
                <p><b>Selected Club:</b> <%= club%></p>
            </div>
        </div>
        <%@ include file="footer.jsp" %>
    </body>
</html>