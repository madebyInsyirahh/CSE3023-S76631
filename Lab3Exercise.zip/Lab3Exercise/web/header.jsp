<%-- 
    Document   : header.jsp
    Created on : 14 Apr 2026, 3:58:24 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Header Page</title>
        <style>
            .header {
                background: linear-gradient(90deg, #2c3e50, #4ca1af);
                color: white;
                padding: 20px;
                text-align: center;
            }

            .nav {
                margin-top: 10px;
            }

            .nav a {
                color: white;
                margin: 0 15px;
                text-decoration: none;
                font-weight: bold;
            }

            .nav a:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
        <div class="header">
            <h2>UMT Student Club Registration System</h2>
            <div class="nav">
                <a href="registerClub.jsp">Registration Page</a>
                <a href="feeCalculator.jsp">Fee Calculator Page</a>
                <a href="memberDirectory.jsp">Club Member Directory</a>
            </div>
        </div>
    </body>
</html>
