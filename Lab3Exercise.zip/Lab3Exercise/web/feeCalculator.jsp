<%-- 
    Document   : feeCalculator
    Created on : 14 Apr 2026, 4:00:12 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Membership Fee Calculator</title>
        <style>
            body {
                font-family: 'Segoe UI', sans-serif;
                margin: 0;
                background-color: #f4f6f9;
            }

            .container {
                width: 60%;
                margin: 40px auto;
                background: white;
                padding: 25px;
                border-radius: 10px;
                box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
                text-align: center;
            }

            h3 {
                color: #2c3e50;
            }

            input {
                width: 80%;
                padding: 10px;
                margin: 10px 0;
                border-radius: 5px;
                border: 1px solid #ccc;
            }

            input[type="submit"] {
                background-color: #3498db;
                color: white;
                border: none;
                cursor: pointer;
                width: 50%;
            }

            input[type="submit"]:hover {
                background-color: #2980b9;
            }

            .result {
                margin-top: 20px;
                padding: 15px;
                background: #eaf2f8;
                border-radius: 8px;
                font-size: 18px;
                color: #2c3e50;
            }
        </style>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <div class="container">
            <h3>Membership Fee Calculator</h3>
            <form method="post">
                Number of Activities:<br>
                <input type="number" name="activities" required>
                <br>
                <input type="submit" value="Calculate">
            </form>
            <%
                if (request.getParameter("activities") != null) {
                    int activities = Integer.parseInt(request.getParameter("activities"));
                    double totalFee = activities * 10.0;
            %>
            <div class="result">
                <b>Total Fee: RM <%= String.format("%.2f", totalFee)%></b>
            </div>
            <%
                }
            %>
        </div>
        <%@ include file="footer.jsp" %>
    </body>
</html>
