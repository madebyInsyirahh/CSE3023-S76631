<%-- 
    Document   : registerClub
    Created on : 14 Apr 2026, 3:59:03 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Club Registration Form</title>
        <style>
            body {
                font-family: 'Segoe UI', sans-serif;
                margin: 0;
                background-color: #f4f6f9;
            }

            .container {
                width: 60%;
                margin: 40px auto;
                background: white;
                padding: 25px;
                border-radius: 10px;
                box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
            }

            h3 {
                text-align: center;
                color: #2c3e50;
            }

            label {
                font-weight: bold;
            }

            input, select {
                width: 100%;
                padding: 10px;
                margin: 8px 0 15px 0;
                border-radius: 5px;
                border: 1px solid #ccc;
            }

            input[type="submit"] {
                background-color: #3498db;
                color: white;
                border: none;
                cursor: pointer;
            }

            input[type="submit"]:hover {
                background-color: #2980b9;
            }
        </style>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <div class="container">
            <h3>Club Registration Form</h3>
            <form action="processRegistration.jsp" method="post">
                <label>Student Name:</label>
                <input type="text" name="studentName" required>
                <label>Matric Number:</label>
                <input type="text" name="matricNo" required>
                <label>Select Club:</label>
                <select name="club">
                    <option>Robotics Club</option>
                    <option>Programming Club</option>
                    <option>Multimedia Club</option>
                    <option>Sports Club</option>
                </select>
                <input type="submit" value="Register">
            </form>
        </div>
        <%@ include file="footer.jsp" %>
    </body>
</html>