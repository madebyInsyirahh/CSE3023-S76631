<%-- 
    Document   : footer
    Created on : 14 Apr 2026, 3:58:39 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Footer Page</title>
        <style>
            .footer {
                background: linear-gradient(90deg, #4ca1af, #2c3e50);
                color: white;
                text-align: center;
                padding: 15px;
                margin-top: 30px;
                font-size: 14px;
                font-weight: bold;
                box-shadow: 0 -2px 10px rgba(0,0,0,0.2);
            }

            .footer a {
                color: #ffffff;
                text-decoration: none;
                font-weight: bold;
            }

            .footer a:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
        <div class="footer">
            ©2026 Faculty of Computer Science and Mathematics, UMT
        </div>
    </body>
</html>
