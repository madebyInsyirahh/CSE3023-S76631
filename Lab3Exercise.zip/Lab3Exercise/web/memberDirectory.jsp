<%-- 
    Document   : memberDirectory
    Created on : 14 Apr 2026, 3:59:32 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<!DOCTYPE html>
<html>
    <head>
        <title>Club Member Directory</title>
        <style>
            body {
                font-family: 'Segoe UI', sans-serif;
                margin: 0;
                background-color: #f4f6f9;
            }

            .container {
                width: 60%;
                margin: 40px auto;
                background: white;
                padding: 25px;
                border-radius: 10px;
                box-shadow: 0px 4px 10px rgba(0,0,0,0.1);
            }

            h3 {
                text-align: center;
                color: #2c3e50;
            }

            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }

            th {
                background-color: #3498db;
                color: white;
            }

            td, th {
                padding: 12px;
                border: 1px solid #ddd;
                text-align: center;
            }

            tr:nth-child(even) {
                background-color: #f2f2f2;
            }

            tr:hover {
                background-color: #d6eaf8;
            }
        </style>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <div class="container">
            <h3>Club Committee Members</h3>
            <%
                ArrayList<String> members = (ArrayList<String>) session.getAttribute("clubDirectory");
            %>
            <table>
                <tr>
                    <th>No</th>
                    <th>Member Details</th>
                </tr>
                <%
                    if (members != null && !members.isEmpty()) {
                        for (int i = 0; i < members.size(); i++) {
                %>
                <tr>
                    <td><%= i + 1%></td>
                    <td><%= members.get(i)%></td>
                </tr>
                <%
                    }
                } else {
                %>
                <tr>
                    <td colspan="2">No members registered yet</td>
                </tr>
                <%
                    }
                %>
            </table>
        </div>
        <%@ include file="footer.jsp" %>
    </body>
</html>