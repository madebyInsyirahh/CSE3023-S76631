<%-- 
    Document   : footer
    Created on : 21 Apr 2026, 4:14:39 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Footer Page</title>
    </head>
    <body>
        <footer style="text-align: center; margin-top: 40px; color: #666; font-size: 0.9rem;">
            <hr>
            <p>&copy; 2026 Faculty of Computer Science and Mathematics, UMT</p>
        </footer>
    </body>
</html>
