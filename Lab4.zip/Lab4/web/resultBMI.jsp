<%-- 
    Document   : resultBMI
    Created on : 21 Apr 2026, 4:15:19 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>BMI Result Page</title>
    </head>
    <body>
        <%@include file="header.jsp" %>
        <h1>BMI Result</h1>

        <div class="card">
            <h2 class="form-title">Your Health Status</h2>

            <%
                String bmiStr = request.getParameter("bmiVal");
                String category = request.getParameter("cat");
                double bmi = Double.parseDouble(bmiStr);
            %>

            <div class="result-box">
                <div class="result-group-flex">
                    <label>Calculated BMI:</label>
                    <p><strong><%= String.format("%.2f", bmi)%></strong></p>
                </div>
                <div class="result-group-flex">
                    <label>Category:</label>
                    <p><strong><%= category%></strong></p>
                </div>
            </div>

            <br>
            <button onclick="window.location.href = 'bmiCalculator.jsp'" class="btn-back">Calculate Again</button>
        </div>
        <%@include file="footer.jsp" %>
    </body>
</html>
