<%-- 
    Document   : insuranceQuotation
    Created on : 21 Apr 2026, 3:34:21 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Insurance Quotation System</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <h1>Insurance Quotation</h1>

            <div class="card">
                <form action="processInsuranceQuo.jsp" method="POST">
                    <fieldset>
                        <legend>Insurance Calculation</legend>

                        <div class="form-group">
                            <label for="icNo">IC No*</label>
                            <input type="text" id="icNo" name="icNo" placeholder="E.g. 921210-01-3478" required 
                                   pattern="[0-9]{6}-[0-9]{2}-[0-9]{4}">
                        </div>

                        <div class="form-group">
                            <label for="name">Name*</label>
                            <input type="text" id="name" name="userName" placeholder="Enter name" required>
                        </div>

                        <div class="form-group">
                            <label for="marketPrice">Market Price*</label>
                            <input type="number" id="marketPrice" name="marketPrice" placeholder="Price" step="0.01" required>
                        </div>

                        <div class="form-group">
                            <label for="coverage">Coverage Type</label>
                            <select id="coverage" name="coverageType">
                                <option value="Third Party">Third Party</option>
                                <option value="Comprehensive">Comprehensive</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="ncd">No Claims Discount (NCD)</label>
                            <select id="ncd" name="ncdPercent">
                                <option value="0">0%</option>
                                <option value="25">25%</option>
                                <option value="30">30%</option>
                                <option value="38.33">38.33%</option>
                                <option value="45">45%</option>
                                <option value="55">55%</option>
                            </select>
                        </div>

                        <div class="button-group">
                            <button type="submit" class="btn-submit">Submit</button>
                            <button type="reset" class="btn-cancel">Cancel</button>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </body>
</html>
