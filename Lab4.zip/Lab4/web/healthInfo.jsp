<%-- 
    Document   : healthInfo
    Created on : 21 Apr 2026, 4:15:27 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList" %>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Health Information</title>
    </head>
    <body>
        <%@include file="header.jsp" %>
        <h1>Health Information</h1>
        <div class="card">
            <h2 class="form-title">BMI Categories Reference</h2>

            <%
                // Step 9: Store categories in ArrayList
                ArrayList<String[]> healthData = new ArrayList<String[]>();
                healthData.add(new String[]{"BMI < 18.5", "Underweight"});
                healthData.add(new String[]{"18.5 <= BMI <= 25", "Normal"});
                healthData.add(new String[]{"BMI > 25", "Overweight"});
            %>

            <div class="result-box">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #f4f7f6; text-align: left;">
                            <th style="padding: 12px; border-bottom: 2px solid #6f42c1;">BMI Range</th>
                            <th style="padding: 12px; border-bottom: 2px solid #6f42c1;">Category</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for (String[] row : healthData) {%>
                        <tr>
                            <td style="padding: 12px; border-bottom: 1px solid #eee;"><%= row[0]%></td>
                            <td style="padding: 12px; border-bottom: 1px solid #eee;"><strong><%= row[1]%></strong></td>
                        </tr>
                        <% }%>
                    </tbody>
                </table>
            </div>
        </div>
        <%@include file="footer.jsp" %>
    </body>
</html>
