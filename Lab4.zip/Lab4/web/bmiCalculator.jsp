<%-- 
    Document   : bmiCalculator
    Created on : 21 Apr 2026, 4:14:53 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>BMI Calculator Page</title>
    </head>
    <body>
        <%@include file="header.jsp" %>
        <h1>BMI Calculator Page</h1>

        <div class="card">
            <h2 class="form-title">Enter Health Details</h2>
            <form action="processBMI.jsp" method="POST">
                <fieldset style="border: 1px solid #ddd; padding: 20px; border-radius: 8px;">
                    <legend style="padding: 0 10px; font-weight: bold;">Body Metrics</legend>

                    <div class="form-group">
                        <label>Weight (kg)*</label>
                        <input type="number" name="weight" step="0.1" placeholder="e.g. 70.5" required>
                    </div>

                    <div class="form-group">
                        <label>Height (m)*</label>
                        <input type="number" name="height" step="0.01" placeholder="e.g. 1.75" required>
                    </div>

                    <div class="button-group">
                        <button type="submit" class="btn btn-back" style="background-color: #6f42c1;">Calculate BMI</button>
                        <button type="reset" class="btn btn-cancel">Clear</button>
                    </div>
                </fieldset>
            </form>
        </div>
        <%@include file="footer.jsp" %>
    </body>
</html>
