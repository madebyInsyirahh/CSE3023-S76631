<%-- 
    Document   : forward
    Created on : 21 Apr 2026, 3:26:17 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Using JSP Standard Action (Forward)</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <h1>Using jsp:forward to display user information</h1>

            <div class="card">
                <h2 class="form-title">Forwarding to forwardInfo.jsp Page</h2>
                
                <jsp:forward page="forwardInfo.jsp">
                    <jsp:param name="uname" value="Wan Nural Jawahir Hj Wan Yussof" />
                    <jsp:param name="email" value="wannurwy@umt.edu.my" />
                    <jsp:param name="nationality" value="Malaysia" />
                    <jsp:param name="background" value="Lecturer" />
                </jsp:forward>
            </div>
        </div>
    </body>
</html>
