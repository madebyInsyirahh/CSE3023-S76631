<%-- 
    Document   : processBMI
    Created on : 21 Apr 2026, 4:15:04 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Retrieve values and calculate
    String weightStr = request.getParameter("weight");
    String heightStr = request.getParameter("height");

    double weight = 0;
    double height = 0;
    double bmi = 0;
    String category = "";

    try {
        weight = Double.parseDouble(weightStr);
        height = Double.parseDouble(heightStr);

        // Formula: BMI = weight / height^2
        if (height > 0) {
            bmi = weight / (height * height);

            // Step 8: Categorization
            if (bmi < 18.5) {
                category = "Underweight";
            } else if (bmi >= 18.5 && bmi <= 25) {
                category = "Normal";
            } else {
                category = "Overweight";
            }
        }
    } catch (Exception e) {
        // Simple error handling
        category = "Invalid Input";
    }
%>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Process BMI Page</title>
    </head>
    <body>
        <%-- Forward results using jsp:param --%>
        <jsp:forward page="resultBMI.jsp">
            <jsp:param name="bmiVal" value="<%= String.valueOf(bmi)%>" />
            <jsp:param name="cat" value="<%= category%>" />
        </jsp:forward>
    </body>
</html>
