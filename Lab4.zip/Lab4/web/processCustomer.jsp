<%-- 
    Document   : processCustomer
    Created on : 21 Apr 2026, 2:12:03 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // --- 1. Business Logic (Scriptlet) ---
    final double price = 10.0;

    // Retrieve form data
    String cust_no = request.getParameter("customerCode");
    String cust_type = request.getParameter("customerType");
    int quantity = 0;

    try {
        quantity = Integer.parseInt(request.getParameter("quantity"));
    } catch (Exception e) {
        quantity = 0;
    }

    // Calculation logic
    double total = 0;
    String message = "";

    if (cust_type != null && cust_type.equals("1") && quantity > 100) {
        message = "You're entitled to 10% discount";
        total = quantity * price * 0.9;
    } else if (cust_type != null && cust_type.equals("2") && quantity > 100) {
        message = "You're entitled to 25% discount";
        total = quantity * price * 0.75;
    } else {
        message = "You're not entitled to any discount";
        total = quantity * price;
    }

    // Human-readable customer type
    String custTypeDisplay = (cust_type != null && cust_type.equals("1"))
            ? "Normal Customer" : "Privilege Customer";
%>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Customer Discount Result</title>
        <link rel="stylesheet" href="style.css">
        <style>
            /* Specific tweaks for Figure 4.5 layout */
            .summary-item {
                margin-bottom: 20px;
            }
            .summary-label {
                font-weight: bold;
                display: block;
                margin-bottom: 5px;
                color: #555;
            }
            .summary-value {
                display: block;
                margin-bottom: 15px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <!-- Main Title as shown in Fig 4.5 -->
            <h1 style="border-left: 5px solid #6f42c1; padding-left: 10px;">Customer Discount Result</h1>

            <div class="card">
                <!-- Transaction Summary Title -->
                <h2 class="form-title">Transaction Summary</h2>

                <!-- Output Details using JSP Expressions -->
                <div class="summary-item">
                    <span class="summary-label">Customer Code:</span>
                    <span class="summary-value"><%= cust_no%></span>
                </div>

                <div class="summary-item">
                    <span class="summary-label">Quantity:</span>
                    <span class="summary-value"><%= quantity%></span>
                </div>

                <div class="summary-item">
                    <span class="summary-label">Customer Type:</span>
                    <span class="summary-value"><%= custTypeDisplay%></span>
                </div>

                <div class="summary-item">
                    <span class="summary-label">Status:</span>
                    <span class="summary-value"><%= message%></span>
                </div>

                <div class="summary-item">
                    <span class="summary-label">Total Amount:</span>
                    <span class="summary-value">RM <%= String.format("%.2f", total)%></span>
                </div>

                <!-- Back Button -->
                <div class="button-group">
                    <button onclick="history.back()" class="btn btn-submit">Back</button>
                </div>
            </div>
        </div>
    </body>
</html>