<%-- 
    Document   : processInsuranceQuo
    Created on : 21 Apr 2026, 3:44:34 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Retrieve form data
    String icno = request.getParameter("icNo");        // matched to name="icNo"
    String name = request.getParameter("userName");    // matched to name="userName"
    String coverage = request.getParameter("coverageType"); // matched to name="coverageType"
    String ncdStr = request.getParameter("ncdPercent"); // matched to name="ncdPercent"

    double price = 0;
    double ncd = 0;
    try {
        price = Double.parseDouble(request.getParameter("marketPrice")); // matched to name="marketPrice"
        ncd = Double.parseDouble(ncdStr) / 100; // Dividing by 100 to work with your formula
    } catch (Exception e) {
        price = 0;
        ncd = 0;
    }

    // Business Logic - Your Formula
    double rate = 0;
    String coverageDisplay = "";
    // Note: Checking for "Comprehensive" (capital C) to match form value
    if ("Comprehensive".equals(coverage)) {
        rate = 0.05; // 5%
        coverageDisplay = "Comprehensive";
    } else {
        rate = 0.03; // 3%
        coverageDisplay = "Third Party";
    }

    // Base insurance calculation
    double insurance = price * rate;

    // Apply NCD discount
    double discount = insurance * ncd;
    double afterNCD = insurance - discount;

    // Add 8% SST
    double sst = afterNCD * 0.08;
    double finalAmount = afterNCD + sst;
%>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Insurance Quotation Result</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <%-- Added the purple left-border style seen in your interface --%>
            <h1 style="border-left: 5px solid #8a2be2; padding-left: 15px;">Insurance Quotation Result</h1>

            <div class="card">
                <p><strong>IC No:</strong><br><%= icno%></p>
                <p><strong>Name:</strong><br><%= name%></p>
                <p><strong>Market Price (RM):</strong><br><%= String.format("%.2f", price)%></p>
                <p><strong>Coverage Type:</strong><br><%= coverageDisplay%></p>
                <p><strong>NCD:</strong><br><%= (int) (ncd * 100)%>%</p>
                <hr>
                <p><strong>Base Insurance:</strong><br>RM <%= String.format("%.2f", insurance)%></p>
                <p><strong>NCD Discount:</strong><br>RM <%= String.format("%.2f", discount)%></p>
                <p><strong>After NCD:</strong><br>RM <%= String.format("%.2f", afterNCD)%></p>
                <p><strong>SST (8%):</strong><br>RM <%= String.format("%.2f", sst)%></p>
                <p><strong>Final Insurance Amount:</strong><br><strong>RM <%= String.format("%.2f", finalAmount)%></strong></p>
                <br>
                <%-- Added inline purple style for the button to match your screenshot --%>
                <button type="button" onclick="history.back()" class="btn-back" style="background-color: #8a2be2; color: white; border: none; padding: 10px 20px; border-radius: 5px;">Back</button>
            </div>
        </div>
    </body>
</html>