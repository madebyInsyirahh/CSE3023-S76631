<%-- 
    Document   : header
    Created on : 21 Apr 2026, 4:12:53 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Healthy Lifestyle Program</title>
        <link rel="stylesheet" href="style.css">
        <style>
            /* Specific nav styling to match the purple theme */
            nav {
                background: #6f42c1;
                padding: 15px;
                margin-bottom: 25px;
                border-radius: 0 0 8px 8px;
            }
            
            nav a {
                color: white;
                margin-right: 20px;
                text-decoration: none;
                font-weight: bold;
            }
            
            nav a:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
        <nav>
            <a href="bmiCalculator.jsp">BMI Calculator</a>
            <a href="healthInfo.jsp">Health Information</a>
        </nav>
        <div class="container">
        </div>
    </body>
</html>
