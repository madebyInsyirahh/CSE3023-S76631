package com.lab.controller;

import com.lab.bean.StudentBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author NurInsyirahJaafar
 */

public class StudentListServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet StudentListServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet StudentListServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Create a list to hold student objects
        List<StudentBean> stdList = new ArrayList<>();
        
        // Adding sample data
        StudentBean s1 = new StudentBean();
        s1.setName("Ali bin Abu");
        s1.setMatricNo("S111");
        StudentBean s2 = new StudentBean();
        s2.setName("Siti Aminah");
        s2.setMatricNo("S222");
        StudentBean s3 = new StudentBean();
        s3.setName("Muthusamy");
        s3.setMatricNo("S333");
        
        stdList.add(s1);
        stdList.add(s2);
        stdList.add(s3);
        
        // Share data with JSP
        request.setAttribute("listData", stdList);
        
        // Forward to View
        RequestDispatcher rd = request.getRequestDispatcher("displayList.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
