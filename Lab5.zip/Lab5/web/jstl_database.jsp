<%-- 
    Document   : jstl_database
    Created on : 29 Apr 2026, 3:54:22 pm
    Author     : NurInsyirahJaafar
--%>

<%@ taglib prefix="c" uri="jakarta.tags.core"%>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt"%>
<%@ taglib prefix="sql" uri="jakarta.tags.sql"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSTL SQL Tags</title>
    </head>
    <body>
        <h2>User List (Fetched directly using JSTL SQL)</h2>
        <sql:setDataSource var="dbConnection" driver="com.mysql.cj.jdbc.Driver"
                           url="jdbc:mysql://localhost:3307/webappdevlab5"
                           user="root" password=""/>
        <sql:query dataSource="${dbConnection}" var="result">
            SELECT * FROM users;
        </sql:query>
        <table border="1" cellpadding="8">
            <thead>
                <tr style="background-color: lightblue;">
                    <th>ID</th>
                    <th>Username</th>
                    <th>Roles</th>
                </tr>
            </thead>   
            <tbody>
                <c:forEach var="row" items="${result.rows}">
                    <tr>
                        <td><c:out value="${row.id}"/></td>
                        <td><c:out value="${row.username}"/></td>
                        <td><c:out value="${row.roles}"/></td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>    
    </body>
</html>
