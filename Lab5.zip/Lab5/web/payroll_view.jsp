<%-- 
    Document   : payroll_view
    Created on : 29 Apr 2026, 4:05:05 pm
    Author     : NurInsyirahJaafar
--%>

<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Employee Payroll Display</title>
        <style>
            body {
                font-family: Arial;
                margin: 30px;
            }

            table {
                width: 80%;
                border-collapse: collapse;
            }

            th, td {
                border: 1px solid black;
                padding: 10px;
                text-align: center;
            }

            th {
                background-color: #009879;
                color: white;
            }
        </style>
    </head>
    <body>
        <h1>Employee Payroll Display System</h1>
        <table>
            <tr>
                <th>Employee ID</th>
                <th>Name</th>
                <th>Department</th>
                <th>Basic Salary (RM)</th>
                <th>Status</th>
            </tr>

            <c:forEach var="emp" items="${employeeList}">
                <tr>
                    <td>${emp.empId}</td>
                    <td>${emp.name}</td>
                    <td>${emp.department}</td>
                    <td>${emp.basicSalary}</td>
                    <td>
                        <c:choose>
                            <c:when test="${emp.basicSalary >= 3000}">
                                Senior
                            </c:when>
                            <c:otherwise>
                                Junior
                            </c:otherwise>
                        </c:choose>
                    </td>
                </tr>
            </c:forEach>
        </table>
    </body>
</html>
