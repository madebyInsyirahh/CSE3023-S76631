<%-- 
    Document   : processCalculateCarLoan
    Created on : 14 Apr 2026, 3:06:37 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Car Loan Result</title>
        <style>
            body {
                font-family: Arial;
            }

            h1 {
                font-size: 28px;
                font-weight: bold;
            }

            fieldset {
                width: 500px;
                margin-top: 20px;
            }

            legend {
                font-weight: bold;
            }

            .footer {
                margin-top: 20px;
            }
        </style>
    </head>
    <body>
        <h2>Perform Car Loan Calculation</h2>
        <fieldset>
            <legend>Loan Calculation</legend>
            <%
                double amount = Double.parseDouble(request.getParameter("amount"));
                int period = Integer.parseInt(request.getParameter("period"));

                double rate = 0.03;
                double total = amount + (amount * rate * period);
            %>
            <h3 style="color: blue;">Details of car loan:</h3>
            <p>Loan Request: <%= amount%></p>
            <p>Period of payment: <%= period%> years</p>
            <p>Total Loan (+Interest): RM <%= String.format("%.2f", total)%></p>
        </fieldset>
        <div class="footer">
            ©2026-Syafiq
        </div>
    </body>
</html>
