<%-- 
    Document   : populateArray
    Created on : 14 Apr 2026, 2:34:44 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Populate Array</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                text-align: center;
            }

            table {
                border-collapse: collapse;
                margin: 20px auto;
                width: 60%;
            }

            th, td {
                border: 1px solid #000;
                padding: 10px;
            }

            th {
                background-color: #D4B24C;
            }
        </style>
    </head>
    <body>
        <h1>Read Java array and populate it into HTML table.</h1>

        <%
            // Create array and store data
            String[] salesman = {"Salesman 1", "Salesman 2", "Salesman 3"};

            int[][] sales = {
                {2500, 2100, 2200},
                {2000, 1900, 2400},
                {1800, 2200, 2450}
            };

            String[] months = {"Jan", "Feb", "Mac"};
        %>

        <table>
            <tr>
                <th>Salesman</th>
                    <% for (String month : months) {%>
                <th><%= month%></th>
                    <% } %>
            </tr>

            <% for (int i = 0; i < salesman.length; i++) {%>
            <tr>
                <td><%= salesman[i]%></td>
                <% for (int j = 0; j < sales[i].length; j++) {%>
                <td><%= sales[i][j]%></td>
                <% } %>
            </tr>
            <% }%>
        </table>
    </body>
</html>
