<%-- 
    Document   : headerPage
    Created on : 14 Apr 2026, 3:46:09 pm
    Author     : NurInsyirahJaafar
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <div style="background-color:#e6cba8; padding:10px; text-align:center; font-weight:bold;">
            ABC Sdn Bhd
        </div>
    </body>
</html>
